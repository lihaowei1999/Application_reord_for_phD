%% 
clear all
load run_test_1_0
for i=1:6
    for j=1:6
        if i*6+j-6<=34
            subplot(6,6,i*6+j-6)
            hold on
            plot(I(i*6+j-6,start_record(i*6+j-6,1):end_record(i*6+j-6,1)),'r','linewidth',2);
            plot(R(i*6+j-6,start_record(i*6+j-6,1):end_record(i*6+j-6,1)),'b','linewidth',2);
            
            plot(I_calc_record(i*6+j-6,1:end_record(i*6+j-6,1)-start_record(i*6+j-6,1)+1),'r--','linewidth',2);
            plot(R_calc_record(i*6+j-6,1:end_record(i*6+j-6,1)-start_record(i*6+j-6,1)+1),'b--','linewidth',2);
            
            hold off
            title(province{i*6+j-6,1})
        end
    end
    
end

%% MSE
mse_I=zeros(34,1);
mse_R=zeros(34,1);
for i=1:34
    mse_I(i,1)=sqrt(sum((I(i,start_record(i,1):end_record(i,1))-I_calc_record(i,1:end_record(i,1)-start_record(i,1)+1)).^2)/(end_record(i,1)-start_record(i,1)+1));
    mse_R(i,1)=sqrt(sum((R(i,start_record(i,1):end_record(i,1))-R_calc_record(i,1:end_record(i,1)-start_record(i,1)+1)).^2)/(end_record(i,1)-start_record(i,1)+1));
end

%% 
rel_mse_I=zeros(34,1);
rel_mse_R=zeros(34,1);
for i=1:34
    rel_mse_I(i,1)=mse_I(i,1)/max(I(i,start_record(i,1):end_record(i,1)));
    rel_mse_R(i,1)=mse_R(i,1)/max(R(i,start_record(i,1):end_record(i,1)));
end

%% 
plot([1:34]',rel_mse_I,[1:34]',rel_mse_R)

%% 
histogram(rel)