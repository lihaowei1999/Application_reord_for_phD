## code list

data_all.mat 所有需要的数据

run_test_1.mat 变gamma变beta拟合结果工作区保存

run_0106_1.mat 变beta拟合工作区保存

solely_sir.m 变beta拟合代码

change_gamma.m 变beta变gamma拟合代码

data_preprocess.m 数据预处理代码

SIR_cost_run.m 变beta考虑传播拟合

after_process 数据后处理

