%% data preprocess
distance=zeros(34,34);
for i=1:34
    for j=1:34
        a=[cos(cord(i,1)*pi/180)*cos(cord(i,2)*pi/180),sin(cord(i,1)*pi/180)*cos(cord(i,2)*pi/180),sin(cord(i,2)*pi/180)];
        b=[cos(cord(j,1)*pi/180)*cos(cord(j,2)*pi/180),sin(cord(j,1)*pi/180)*cos(cord(j,2)*pi/180),sin(cord(j,2)*pi/180)];
        distance(i,j)=norm(a-b)*6371;
    end
end

%%
I=zeros(34,166);
R=zeros(34,166);

for i=1:5534
    waitbar(i/5534)
    for j=1:34
        a=dt{i,1};
        b=province_name{j,1};
        
        if a(1:2)==b(1:2)
            prov_num=j;
        end
    end
    for j=1:166
        if dt2(i,1)==ll(j,1);
            I(prov_num,j)=dt2(i,3);
            R(prov_num,j)=dt2(i,2)+dt2(i,4);
        end
    end
end


