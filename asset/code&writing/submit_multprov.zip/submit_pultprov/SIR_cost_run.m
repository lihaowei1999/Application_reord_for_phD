%% calc_cost run test
calc_cost([1,1,1,1],[5,5,5,5],[2,2,2,2],[7,7,7,7],1)

%% softmax run test
softmax([1,3,4;3,5,2],-3)

%% beta_calc test
% beta=beta_calc(beta0,lambda,omega,gamma,t)
S0=[2000000;2000000;2000000];
I0=[2;2;2];
R0=[0;0;0];
fi=[0.0001;0.0001;0.0001];
a=-0.0001;
gamma=0.01;
beta_0=0.3;
lambda=0.03;
omega=0.03;
t=1000;
par=1;
beta_s=0.7*gamma;
plot([0:t-1],beta_calc(beta_0,lambda,omega,gamma,t,beta_s))

%% ReLU
ReLU([-1,0,0.1])

%% Model generate
% [S_calc,I_calc,R_calc]=Model_generate_t(S0,I0,R0,fi,a,gamma,beta_0,lamda,omega,t)
S0=[2000000;2000000;2000000];
I0=[2;2;2];
R0=[0;0;0];
fi=[0.0001;0.0001;0.0001];
a=-1;
gamma=0.01;
beta_0=0.3;
lambda=0.05;
omega=0.03;
t=1000;
beta_s=0.7*gamma;
[S_calc,I_calc,R_calc]=Model_generate_t(S0,I0,R0,fi,a,gamma,beta_0,lambda,omega,t,beta_s);
figure
plot([1:t],beta_calc(beta_0,lambda,omega,gamma,t,beta_s))
figure
hold on
%plot(S_calc(1,:));
plot(I_calc(1,:));
plot(R_calc(1,:));
hold off


%% 

%%
load data_all

for i=1:34
    distance(i,i)=99999;
end

a=-0.00001;
gamma=0.01;
beta_0=0.3;
lambda=0.05;
omega=0.05;
t=1000;
beta_s=0.3*gamma;
cost_para=1;
I1=I(:,5:end);
S1=S(:,5:end);
R1=R(:,5:end);

pr=1/10^8;
fi=gdp*pr;

SIR_cost(S1(:,1),I1,R1,distance,fi,a,gamma,beta_0,lambda,omega,cost_para,beta_s)

%% 
load data_all

for i=1:34
    distance(i,i)=99999;
end
a=-0.00001;
gamma=0.01;
beta_0=0.3;
lambda=0.05;
omega=0.05;
t=1000;
beta_s=0.3*gamma;
cost_para=1;
fi_ratio=1/10^8;
num=50;
para=[a,gamma,beta_0,lambda,omega,beta_s,fi_ratio];
tic
cost=train_cost(para,S,I,R,distance,gdp,cost_para,num)
toc
%% 
clear all
load data_all

for i=1:34
    distance(i,i)=99999;
end

select=[1:22,24:29,31:32];
select=[1:34];
a=-0.00001;
gamma=0.01;
beta_0=0.3;
lambda=0.05;
omega=0.05;
t=1000;
beta_s=0.3*gamma;
cost_para=1;
fi_ratio=1/10^6;
num=60;
para=[a,gamma,beta_0,lambda,omega,beta_s,fi_ratio]*1e8;


options = optimoptions(@fminunc,'Display','iter','Algorithm','quasi-newton','MaxFunctionEvaluations',1e5);

[x,fval]=fminunc(@train_cost,para,options,S(select,:),I(select,:),R(select,:),distance(select,select),flow(select,:),cost_para,num);


depic(x,S(select,:),I(select,:),R(select,:),distance(select,select),flow(select,:),province)

x/1e8

%% 
% here we suppose S,I,R in matrix provinces * days
% D in matrix provinces * provinces, not pre soft-maxed, i to j transfer
% condsider the viariation of total num, N=S+I+R
% a 
% fi as provinces * 1
% gamma 
% beta_0
% lambda
% omega

function depic(para,S,I,R,distance,flow,province)
    para2=para/1e8;
    a=para2(1);
    gamma=para2(2);
    beta_0=para2(3);
    lambda=para2(4);
    omega=para2(5);
    beta_s=para2(6);
    fi_ratio=para2(7);
    I1=I(:,5:size(I,2));
    S1=S(:,5:size(I,2));
    R1=R(:,5:size(I,2));
    fi=fi_ratio*flow;
    
    [S_calc,I_calc,R_calc]=Model_generate(S1(:,1),I1(:,1),R1(:,1),distance,fi,a,gamma,beta_0,lambda,omega,size(I1,2),beta_s);
    
    figure
    for i=1:6
        for j=1:6
            if i*6+j-6<=size(S,1)
                subplot(6,6,i*6+j-6)
                hold on
                plot(R1(i*6+j-6,:),'r','linewidth',2)
                plot(I1(i*6+j-6,:),'b','linewidth',2)
                plot(R_calc(i*6+j-6,1:size(I1,2)),'r--','linewidth',2)
                plot(I_calc(i*6+j-6,1:size(I1,2)),'b--','linewidth',2)
                title(province{i*6+j-6,1})
                hold off
            end
        end
    end
%     
%     I_sum=sum(I1,1);
%     R_sum=sum(R1,1);
%     I_cal_sum=sum(I_calc,1);
%     R_cal_sum=sum(R_calc,1);
%     
%     figure
%     hold on
%     plot(R_sum)
%     plot(I_sum)
%     plot(R_cal_sum(1,1:size(I1,2)))
%     plot(I_cal_sum(1,1:size(I1,2)))
%     hold off
    
    

end


function cost=train_cost(para,S,I,R,d_raw,flow,cost_para,num)
    para2=para/1e8;
    a=para2(1);
    gamma=para2(2);
    beta_0=para2(3);
    lambda=para2(4);
    omega=para2(5);
    beta_s=para2(6);
    fi_ratio=para2(7);
    I1=I(:,5:num);
    S1=S(:,5:num);
    R1=R(:,5:num);
    fi=fi_ratio*flow;
    
    
    
    cost=SIR_cost(S1(:,1),I1,R1,d_raw,fi,a,gamma,beta_0,lambda,omega,cost_para,beta_s);
    
    
    if beta_s>gamma
        cost=cost+1000000*(beta_s-gamma);
    end
    
    

end


function cost=SIR_cost(S0,I,R,d_raw,fi,a,gamma,beta_0,lambda,omega,cost_para,beta_s)
    R0=R(:,1);
    I0=I(:,1);
    [S_calc,I_calc,R_calc]=Model_generate(S0,I0,R0,d_raw,fi,a,gamma,beta_0,lambda,omega,size(R,2)*5,beta_s);
    cost=calc_cost(I,R,I_calc(:,1:size(R,2)),R_calc(:,1:size(R,2)),cost_para);
    % keyboard
end

% 损失函数，初始设置为I和R的MSE的加权和
function cost=calc_cost(I,R,I_calc,R_calc,cost_para)
    sigma=cost_para(1);
    cost=(sqrt(sum(sum((I-I_calc).^2))/size(I,2)/size(I,1))+sigma*sqrt(sum(sum((R-R_calc).^2))/size(R,2)/size(R,1)))/(1+sigma);
    
end

% 计算模型
function [S_calc,I_calc,R_calc]=Model_generate(S0,I0,R0,d_raw,fi,a,gamma,beta_0,lambda,omega,t,beta_s)
    d=softmax(d_raw,a);
    S=zeros(size(S0,1),t);
    I=zeros(size(I0,1),t);
    R=zeros(size(R0,1),t);
    S(:,1)=S0;
    I(:,1)=I0;
    R(:,1)=R0;
    % d_in(i,j)=k(i,j)

    d_in=d.*repmat(fi,[1,size(fi,1)]);
    beta=beta_calc(beta_0,lambda,omega,gamma,t,beta_s);
    for day=2:t
        S_input=d_in'*S(:,day-1);
        I_input=d_in'*I(:,day-1);
        S(:,day)=S(:,day-1)+S_input-fi.*S(:,day-1)-S(:,day-1).*I(:,day-1)*beta(day-1)./(S(:,day-1)+I(:,day-1)+R(:,day-1));
        I(:,day)=I(:,day-1)+I_input-fi.*I(:,day-1)+S(:,day-1).*I(:,day-1)*beta(day-1)./(S(:,day-1)+I(:,day-1)+R(:,day-1))-gamma*I(:,day-1);
        R(:,day)=R(:,day-1)+gamma*I(:,day-1);
    end
    S_calc=S;
    I_calc=I;
    R_calc=R;
end



function d=softmax(d_raw,a)
    d_exp=exp(a*d_raw);
    d=d_exp./repmat(sum(d_exp,2),[1,size(d_exp,2)]);
end

function beta=beta_calc(beta0,lambda,omega,gamma,t,beta_s)
    
    beta_1=beta_s/gamma*((beta0-gamma)*exp(-lambda*[0:(t-1)]).*cos(omega*[0:(t-1)])+gamma);
    beta_2=beta_s*exp((beta0-gamma)/gamma*exp(-lambda*[0:(t-1)]).*cos(omega*[0:(t-1)]));
    cosw=cos(omega*[0:t-1]);
    beta_1(cosw<0)=beta_2(cosw<0);
    beta=beta_1; 
end

% 激活函数
function x=ReLU(a)
    x=max(a,zeros(size(a)));
end






