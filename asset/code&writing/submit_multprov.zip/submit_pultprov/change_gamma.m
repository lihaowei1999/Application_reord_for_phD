%% solely SIR
clear all
load data_all


select=[12];
a=-0.00001;
gamma=0.01;
beta_0=0.3;
lambda=0.05;
omega=0.05;
t=1000;
beta_s=0.3*gamma;
cost_para=1;
fi_ratio=1/10^6;
start=10;
num=100;
gamma_inf=0.02;
lambda_2=0.05;
para=[gamma,beta_0,lambda,omega,beta_s,gamma_inf,lambda_2]*1e4;


options = optimoptions(@fminunc,'Display','iter','Algorithm','quasi-newton','MaxFunctionEvaluations',1e5,'MaxIterations',10000);

[x,fval]=fminunc(@train_cost,para,options,S(select,:),I(select,:),R(select,:),cost_para,start,num);

[I_ret,R_ret]=ret_valu(x,S(select,:),I(select,:),R(select,:),start,num);

figure
hold on
num=160;
plot(I(select,start:num));
plot(R(select,start:num));
plot(I_ret(1,1:num-start+1));
plot(R_ret(1,1:num-start+1));
hold on

%% run all province
load test_0106

%%
run_end=ones(34,1)*100;
store_size=120;
I_calc_stor=zeros(34,store_size);
R_calc_stor=zeros(34,store_size);
start_stor=zeros(34,1);
end_stor=zeros(34,1);
para_stor=zeros(34,7);
cost_stor=zeros(34,1);
for i=1:34
    x_temp=zeros(10,7);
    fval_temp=zeros(10,1);
    for start=1:10
        waitbar((start+i*10-10)/340)
        select=[i];
        a=-0.00001;
        gamma=0.01;
        beta_0=0.3;
        lambda=0.05;
        omega=0.05;
        t=1000;
        beta_s=0.3*gamma;
        cost_para=1;
        fi_ratio=1/10^6;
        num=run_end(i,1);
        gamma_inf=0.02;
        lambda_2=0.05;
        para=[gamma,beta_0,lambda,omega,beta_s,gamma_inf,lambda_2]*1e4;


        options = optimoptions(@fminunc,'Display','iter','Algorithm','quasi-newton','MaxFunctionEvaluations',1e7,'MaxIterations',15000);

        [x_temp(start,:),fval_temp(start,1)]=fminunc(@train_cost,para,options,S(select,:),I(select,:),R(select,:),cost_para,start,num);
        
        
        
        
        
    end
    [val,pos]=min(fval_temp);
    para_real=x_temp(pos,:);
    
    [I_ret,R_ret]=ret_valu(para_real,S(select,:),I(select,:),R(select,:),pos,num);
    I_calc_stor(i,:)=I_ret(1:store_size);
    R_calc_stor(i,:)=R_ret(1:store_size);
    start_stor(i,1)=pos;
    end_stor(i,1)=run_end(i,1);
    para_stor(i,:)=para_real;
    cost_stor(i,1)=val;
    figure
    hold on
    
    plot(I(select,start_stor(i,1):end_stor(i,1)));
    plot(R(select,start_stor(i,1):end_stor(i,1)));
    plot(I_ret(1,1:(end_stor(i,1)-start_stor(i,1)+1)));
    plot(R_ret(1,1:(end_stor(i,1)-start_stor(i,1)+1)));
    hold off
    title(province{i,1})
    keyboard
end


%% 

figure
for i=1:6
    for j=1:6
        select=i*6+j-6;
        if select<=34
            subplot(6,6,select);
            hold on
            plot(I(select,(start_stor(select,1):end_stor(select,1))),'r','linewidth',2);
            plot(R(select,(start_stor(select,1):end_stor(select,1))),'b','linewidth',2);
            plot(I_calc_stor(select,1:(end_stor(select,1)-start_stor(select,1)+1)),'r--','linewidth',2);
            plot(R_calc_stor(select,1:(end_stor(select,1)-start_stor(select,1)+1)),'b--','linewidth',2);
            hold off
            title(province{select,1})
        end
    end
end
%% 
ed=120
figure
for i=1:6
    for j=1:6
        select=i*6+j-6;
        if select<=34
            subplot(6,6,select);
            hold on
            plot(I(select,(start_stor(select,1):ed)),'r','linewidth',2);
            plot(R(select,(start_stor(select,1):ed)),'b','linewidth',2);
            plot(I_calc_stor(select,1:(ed-start_stor(select,1)+1)),'r--','linewidth',2);
            plot(R_calc_stor(select,1:(ed-start_stor(select,1)+1)),'b--','linewidth',2);
            hold off
            title(province{select,1})
        end
    end
end



%% 

function [I_ret,R_ret]=ret_valu(para,S,I,R,start,num)
    para2=para/1e4;
    gamma=para2(1);
    beta_0=para2(2);
    lambda=para2(3);
    omega=para2(4);
    beta_s=para2(5);
    gamma_inf=para2(6);
    lambda_2=para2(7);
    I1=I(:,start:num);
    S1=S(:,start:num);
    R1=R(:,start:num);
    S0=S1(1,1);
    I0=I1(1,1);
    R0=R1(1,1);
    t=size(S,2)*5;
    
    [S_r,I_r,R_r]=Model_generate(S0,I0,R0,gamma,beta_0,lambda,omega,t,beta_s,gamma_inf,lambda_2);
    I_ret=I_r;
    R_ret=R_r;
end

function cost=train_cost(para,S,I,R,cost_para,start,num)
    para2=para/1e4;
    gamma=para2(1);
    beta_0=para2(2);
    lambda=para2(3);
    omega=para2(4);
    beta_s=para2(5);
    gamma_inf=para2(6);
    lambda_2=para2(7);
    I1=I(:,start:num);
    S1=S(:,start:num);
    R1=R(:,start:num);
    
    
    
    cost=SIR_cost(S1(:,1),I1,R1,gamma,beta_0,lambda,omega,cost_para,beta_s,gamma_inf,lambda_2);
    
    
%     if beta_s>gamma
%         cost=cost+1000000*(beta_s-gamma);
%     end
    
    

end


function cost=SIR_cost(S0,I,R,gamma,beta_0,lambda,omega,cost_para,beta_s,gamma_inf,lambda_2)
    R0=R(:,1);
    I0=I(:,1);
    [S_calc,I_calc,R_calc]=Model_generate(S0,I0,R0,gamma,beta_0,lambda,omega,size(R,2)*5,beta_s,gamma_inf,lambda_2);
    cost=calc_cost(I,R,I_calc(:,1:size(R,2)),R_calc(:,1:size(R,2)),cost_para);
    % keyboard
end

% 损失函数，初始设置为I和R的MSE的加权和
function cost=calc_cost(I,R,I_calc,R_calc,cost_para)
    sigma=cost_para(1);
    %cost=(sqrt(sum(sum((I-I_calc).^2))/size(I,2)/size(I,1))+sigma*sqrt(sum(sum((R-R_calc).^2))/size(R,2)/size(R,1)))/(1+sigma);
    cost=(sqrt(sum((I-I_calc).^2)/(size(I,1)))+sigma*sqrt(sum((R-R_calc).^2)/(size(R,1))))/(1+sigma);
end

% 计算模型
function [S_calc,I_calc,R_calc]=Model_generate(S0,I0,R0,gamma,beta_0,lambda,omega,t,beta_s,gamma_inf,lambda_2)
    S=zeros(size(S0,1),t);
    I=zeros(size(I0,1),t);
    R=zeros(size(R0,1),t);
    S(:,1)=S0;
    I(:,1)=I0;
    R(:,1)=R0;
    % d_in(i,j)=k(i,j)

    beta=beta_calc(beta_0,lambda,omega,gamma,t,beta_s);
    gamma_real=gamma_calc(gamma,gamma_inf,lambda_2,t);
    for day=2:t
        S(:,day)=S(:,day-1)-S(:,day-1).*I(:,day-1)*beta(day-1)./(S(:,day-1)+I(:,day-1)+R(:,day-1));
        I(:,day)=I(:,day-1)+S(:,day-1).*I(:,day-1)*beta(day-1)./(S(:,day-1)+I(:,day-1)+R(:,day-1))-gamma_real(day-1)*I(:,day-1);
        R(:,day)=R(:,day-1)+gamma_real(day-1)*I(:,day-1);
    end
    S_calc=S;
    I_calc=I;
    R_calc=R;
end


function beta=beta_calc(beta0,lambda,omega,gamma,t,beta_s)
    
    beta_1=beta_s/gamma*((beta0-gamma)*exp(-lambda*[0:(t-1)]).*cos(omega*[0:(t-1)])+gamma);
    beta_2=beta_s*exp((beta0-gamma)/gamma*exp(-lambda*[0:(t-1)]).*cos(omega*[0:(t-1)]));
    cosw=cos(omega*[0:t-1]);
    beta_1(cosw<0)=beta_2(cosw<0);
    beta=beta_1; 
end
function gamma_c=gamma_calc(gamma,gamma_inf,lambda_2,t)
    gamma_c=1./(1/gamma_inf+(1/gamma-1/gamma_inf)*exp(-lambda_2*[1:t-1]));
end


% 激活函数
function x=ReLU(a)
    x=max(a,zeros(size(a)));
end

