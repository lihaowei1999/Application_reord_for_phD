%% solely SIR
clear all
load data_all


select=[3];
a=-0.00001;
gamma=0.01;
beta_0=0.3;
lambda=0.05;
omega=0.05;
t=1000;
beta_s=0.3*gamma;
cost_para=1;
fi_ratio=1/10^6;
start=10;
num=60;
para=[gamma,beta_0,lambda,omega,beta_s]*1e4;


options = optimoptions(@fminunc,'Display','iter','Algorithm','quasi-newton','MaxFunctionEvaluations',1e5,'MaxIterations',10000);

[x,fval]=fminunc(@train_cost,para,options,S(select,:),I(select,:),R(select,:),cost_para,start,num);

[I_ret,R_ret]=ret_valu(x,S(select,:),I(select,:),R(select,:),start,num);

figure
hold on
plot(I(select,start:num));
plot(R(select,start:num));
plot(I_ret(1,1:num-start+1));
plot(R_ret(1,1:num-start+1));
hold on

%% 

function [I_ret,R_ret]=ret_valu(para,S,I,R,start,num)
    para2=para/1e4;
    gamma=para2(1);
    beta_0=para2(2);
    lambda=para2(3);
    omega=para2(4);
    beta_s=para2(5);
    I1=I(:,start:num);
    S1=S(:,start:num);
    R1=R(:,start:num);
    S0=S1(1,1);
    I0=I1(1,1);
    R0=R1(1,1);
    t=size(S,2)*5;
    
    [S_r,I_r,R_r]=Model_generate(S0,I0,R0,gamma,beta_0,lambda,omega,t,beta_s);
    I_ret=I_r;
    R_ret=R_r;
end

function cost=train_cost(para,S,I,R,cost_para,start,num)
    para2=para/1e4;
    gamma=para2(1);
    beta_0=para2(2);
    lambda=para2(3);
    omega=para2(4);
    beta_s=para2(5);
    I1=I(:,start:num);
    S1=S(:,start:num);
    R1=R(:,start:num);
    
    
    
    cost=SIR_cost(S1(:,1),I1,R1,gamma,beta_0,lambda,omega,cost_para,beta_s);
    
    
%     if beta_s>gamma
%         cost=cost+1000000*(beta_s-gamma);
%     end
    
    

end


function cost=SIR_cost(S0,I,R,gamma,beta_0,lambda,omega,cost_para,beta_s)
    R0=R(:,1);
    I0=I(:,1);
    [S_calc,I_calc,R_calc]=Model_generate(S0,I0,R0,gamma,beta_0,lambda,omega,size(R,2)*5,beta_s);
    cost=calc_cost(I,R,I_calc(:,1:size(R,2)),R_calc(:,1:size(R,2)),cost_para);
    % keyboard
end

% 损失函数，初始设置为I和R的MSE的加权和
function cost=calc_cost(I,R,I_calc,R_calc,cost_para)
    sigma=cost_para(1);
    %cost=(sqrt(sum(sum((I-I_calc).^2))/size(I,2)/size(I,1))+sigma*sqrt(sum(sum((R-R_calc).^2))/size(R,2)/size(R,1)))/(1+sigma);
    cost=(sqrt(sum((I-I_calc).^2)/(size(I,1)))+sigma*sqrt(sum((R-R_calc).^2)/(size(R,1))))/(1+sigma);
end

% 计算模型
function [S_calc,I_calc,R_calc]=Model_generate(S0,I0,R0,gamma,beta_0,lambda,omega,t,beta_s)
    S=zeros(size(S0,1),t);
    I=zeros(size(I0,1),t);
    R=zeros(size(R0,1),t);
    S(:,1)=S0;
    I(:,1)=I0;
    R(:,1)=R0;
    % d_in(i,j)=k(i,j)

    beta=beta_calc(beta_0,lambda,omega,gamma,t,beta_s);
    for day=2:t
        S(:,day)=S(:,day-1)-S(:,day-1).*I(:,day-1)*beta(day-1)./(S(:,day-1)+I(:,day-1)+R(:,day-1));
        I(:,day)=I(:,day-1)+S(:,day-1).*I(:,day-1)*beta(day-1)./(S(:,day-1)+I(:,day-1)+R(:,day-1))-gamma*I(:,day-1);
        R(:,day)=R(:,day-1)+gamma*I(:,day-1);
    end
    S_calc=S;
    I_calc=I;
    R_calc=R;
end


function beta=beta_calc(beta0,lambda,omega,gamma,t,beta_s)
    
    beta_1=beta_s/gamma*((beta0-gamma)*exp(-lambda*[0:(t-1)]).*cos(omega*[0:(t-1)])+gamma);
    beta_2=beta_s*exp((beta0-gamma)/gamma*exp(-lambda*[0:(t-1)]).*cos(omega*[0:(t-1)]));
    cosw=cos(omega*[0:t-1]);
    beta_1(cosw<0)=beta_2(cosw<0);
    beta=beta_1; 
end

% 激活函数
function x=ReLU(a)
    x=max(a,zeros(size(a)));
end

